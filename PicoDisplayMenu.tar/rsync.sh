rshell -f rsync.cmd
